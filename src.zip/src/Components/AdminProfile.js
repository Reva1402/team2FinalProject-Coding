import React, { useEffect, useState } from 'react';
import { db, auth } from './firebaseConfig';
import './AdminProfile.css';

function Profile() {
  const [profileData, setProfileData] = useState({});
  const [editMode, setEditMode] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProfileData = async () => {
      const userId = auth.currentUser?.uid;
      if (userId) {
        const doc = await db.collection('users').doc(userId).get();
        if (doc.exists) {
          setProfileData(doc.data());
        }
      }
      setLoading(false);
    };

    fetchProfileData();
  }, []);

  const handleEdit = () => {
    setEditMode(true); // Enable edit mode
  };

  const handleSave = async () => {
    const userId = auth.currentUser?.uid;
    if (userId) {
      try {
        await db.collection('users').doc(userId).update(profileData);
        console.log('Profile updated successfully');
        setEditMode(false); // Disable edit mode after saving
      } catch (error) {
        console.error("Error updating profile:", error);
      }
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setProfileData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleDelete = async () => {
    const userId = auth.currentUser?.uid;
    if (!userId) return;

    if (window.confirm('Are you sure you want to delete your profile?')) {
      try {
        await db.collection('users').doc(userId).delete();
        await auth.currentUser.delete();
        console.log('Profile deleted');
        // Redirect or update UI after deletion
      } catch (error) {
        if (error.code === 'auth/requires-recent-login') {
          alert("Please log in again to delete your account.");
        } else {
          console.error("Error deleting profile:", error);
        }
      }
    }
  };

  if (loading) return <p>Loading...</p>;

  return (
    <div className="profile-container">
      <div className="profile-box">
        <img src={profileData.photoURL || 'default-profile.png'} alt="Profile" className="profile-image" />

        {editMode ? (
          <>
            <input
              type="text"
              name="name"
              value={profileData.name || ''}
              onChange={handleChange}
              placeholder="Name"
              className="profile-input"
            />
            <input
              type="email"
              name="email"
              value={profileData.email || ''}
              onChange={handleChange}
              placeholder="Email"
              className="profile-input"
              disabled
            />
            <input
              type="text"
              name="phone"
              value={profileData.phone || ''}
              onChange={handleChange}
              placeholder="Mobile Number"
              className="profile-input"
            />
            <input
              type="text"
              name="address"
              value={profileData.address || ''}
              onChange={handleChange}
              placeholder="Address"
              className="profile-input"
            />
          </>
        ) : (
          <>
            <p className="profile-info"><strong>Name:</strong> {profileData.name || 'User Name'}</p>
            <p className="profile-info"><strong>Email:</strong> {profileData.email || 'user@example.com'}</p>
            <p className="profile-info"><strong>Mobile Number:</strong> {profileData.phone || '123-456-7890'}</p>
            <p className="profile-info"><strong>Address:</strong> {profileData.address || '1234, Street Name, City, State, Zip'}</p>
          </>
        )}

        <div className="buttons">
          {editMode ? (
            <button onClick={handleSave} className="button-save">Save Changes</button>
          ) : (
            <button onClick={handleEdit} className="button-edit">Edit Profile</button>
          )}
          <button onClick={handleDelete} className="button-delete">Delete Profile</button>
        </div>
      </div>
    </div>
  );
}

export default Profile;
