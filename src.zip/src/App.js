import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import AdminDashboard from './Components/AdminDashboard';
import UserManagement from './Components/UserManagement';
import AdminProfile from './Components/AdminProfile';
 import LoginPage from './Components/LoginPage';
import SignupPage from './Components/SignupPage';
import ForgotPassword from './Components/ForgotPassword';
import UserHomePage from './Components/UserHomePage';
import UserEditProfile from './Components/UserEditProfile';
import CreateEvent from './Components/CreateEvent';
import EventAttendance from './Components/EventAttendance';
import MyEvents from './Components/MyEvents';
import UserProfile from './Components/UserProfile';

function App() {
  return (
    <Router>
      <Routes>
       <Route path="/" element={<SignupPage />} />
       <Route path="/LoginPage" element={<LoginPage />} />
       
       <Route path="/admins" element={<AdminDashboard />} />
        <Route path="/users" element={<UserManagement />} />
        <Route path="/profile" element={<AdminProfile />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/userhome" element={<UserHomePage />} />
        <Route path="/editprofile" element={<UserEditProfile />} />
        <Route path="/createevent" element={<CreateEvent />} />
        <Route path="/event/:eventId" element={<EventAttendance />} />
        <Route path="/myevents" element={<MyEvents />} />
        <Route path="/userprofile" element={<UserProfile />} />
      
      </Routes>
    </Router>
  );
}

export default App;
