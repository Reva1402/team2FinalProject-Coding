import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { auth, firestore, storage } from './firebaseConfig';
import { doc, getDoc, updateDoc } from 'firebase/firestore';
import { signOut } from 'firebase/auth';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage'; 
import './AdminEditProfile.css';

const AdminEditProfile = () => {
  const [userProfile, setUserProfile] = useState(null);
  const [editData, setEditData] = useState({
    mobileNumber: '',
    address: '',
    profilePicture: '',
  });
  const [profilePicFile, setProfilePicFile] = useState(null); 
  const [base64ProfilePic, setBase64ProfilePic] = useState(''); 
  const navigate = useNavigate();
  const user = auth.currentUser;

  useEffect(() => {
    const fetchUserProfile = async () => {
      if (user) {
        const userRef = doc(firestore, 'users', user.uid);
        const docSnap = await getDoc(userRef);
        if (docSnap.exists()) {
          setUserProfile(docSnap.data());
          setEditData({
            mobileNumber: docSnap.data().mobileNumber || '',
            address: docSnap.data().address || '',
            profilePicture: docSnap.data().profilePicture || '',
          });
        } else {
          console.log('No such document!');
        }
      }
    };
    fetchUserProfile();
  }, [user]);

  
  const handleChange = (e) => {
    const { name, value } = e.target;
    setEditData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  
  const handleProfilePicChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setProfilePicFile(file);

     
      const reader = new FileReader();
      reader.onloadend = () => {
        setBase64ProfilePic(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  
  const handleSave = async () => {
    try {
      let updatedData = { ...editData };

    
      if (profilePicFile) {
        const profilePicRef = ref(storage, `profile_pictures/${user.uid}`);
        await uploadBytes(profilePicRef, profilePicFile);
        const picUrl = await getDownloadURL(profilePicRef);
        updatedData.profilePicture = picUrl; 
      }

      
      const userRef = doc(firestore, 'users', user.uid);
      await updateDoc(userRef, updatedData);

      
      alert('Profile updated successfully!');
    } catch (error) {
      console.error('Error updating profile:', error);
      alert('Failed to update profile. Please try again.');
    }
  };

  return (
    <div className="edit-profile-container">
      <header className="header">
        <div className="header-left">
          <h1>Admin One</h1>
        </div>
        <div className="header-right">
          <button onClick={() => navigate('/AdminProfile')} className="profile-button">Profile</button>
          <button onClick={() => signOut(auth).then(() => navigate('/login'))} className="logout-button">Log Out</button>
        </div>
      </header>

      <div className="form-container">
        <h2>Edit Profile</h2>
        <div className="form-group">
          <label>Mobile Number:</label>
          <input
            type="text"
            name="mobileNumber"
            value={editData.mobileNumber}
            onChange={handleChange}
            placeholder="Enter your mobile number"
          />
        </div>
        <div className="form-group">
          <label>Address:</label>
          <input
            type="text"
            name="address"
            value={editData.address}
            onChange={handleChange}
            placeholder="Enter your address"
          />
        </div>
        <div className="form-group">
          <label>Profile Picture:</label>
          <input
            type="file"
            onChange={handleProfilePicChange}
            accept="image/*"
          />
          {base64ProfilePic && (
            <div>
              <img
                src={base64ProfilePic}
                alt="Profile"
                className="profile-pic-preview"
                style={{ width: 100, height: 100, borderRadius: '50%' }}
              />
            </div>
          )}
        </div>
        <button onClick={handleSave} className="save-button">Save Profile</button>
      </div>

      <footer className="footer">
        <ul className="footer-links">
          <li onClick={() => navigate('/about')}>About</li>
          <li onClick={() => navigate('/privacypolicy')}>Privacy Policy</li>
          <li onClick={() => navigate('/termsandconditions')}>Terms and Conditions</li>
          <li onClick={() => navigate('/contactus')}>Contact Us</li>
        </ul>
      </footer>
    </div>
  );
};

export default AdminEditProfile;
