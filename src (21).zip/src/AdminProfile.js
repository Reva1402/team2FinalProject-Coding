import React, { useEffect, useState } from 'react';
import { getFirestore, doc, getDoc } from 'firebase/firestore';
import { getAuth , signOut} from 'firebase/auth';
import { useNavigate, Link} from 'react-router-dom';
import './AdminProfile.css';

const AdminProfile = () => {
  const [adminData, setAdminData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  const auth = getAuth();
  const db = getFirestore();
  const navigate = useNavigate();

  useEffect(() => {
    const fetchAdminData = async () => {
      try {
        const uid = auth.currentUser?.uid;
        if (uid) {
          const docRef = doc(db, 'users', uid);
          const docSnap = await getDoc(docRef);

          if (docSnap.exists() && docSnap.data().role === "admin") {
            setAdminData(docSnap.data());
          } else {
            console.error('Admin profile not found or user is not an admin.');
          }
        }
      } catch (error) {
        console.error('Error fetching admin profile:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchAdminData();
  }, [auth, db]);

  if (loading) return <div>Loading...</div>;
  if (!adminData) return <div>No profile data available.</div>;

  const handleLogout = async () => {
    try {
      await signOut(auth);
      navigate("/login");
    } catch (error) {
      console.error("Logout error:", error);
    }
  };

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value.toLowerCase());
  };

  return (
    <div className="profile-container">
      <header className="navbar">
        <h1 onClick={() => navigate('/AdminDashboard')}>Admin One</h1>
        <div className="navbar-right">
          <input
            type="text"
            placeholder="Search..."
            className="search-bar"
            onChange={handleSearchChange}
            value={searchQuery}
          />
          <Link to="/AdminProfile" className="profile-link">Profile</Link>
          <button className="logout-btn" onClick={handleLogout}>Log Out</button>
        </div>
      </header>
      <div className="profile-card">
        {adminData.profilepicture && (
          <img 
            src={adminData.profilepicture} 
            alt="Admin Profile" 
            className="profile-picture"
          />
        )}
        <div className="profile-info">
          <p><strong>Name:</strong> {adminData.firstName} {adminData.lastName}</p>
          <p><strong>Email:</strong> {adminData.email}</p>
          <p><strong>Mobile Number:</strong> {adminData.mobilenumber}</p>
          <p><strong>Address:</strong> {adminData.address}</p>
        </div>
        <div className="profile-actions">
          <button className="edit-btn" onClick={() => navigate('/AdminEditProfile')}>Edit Profile</button>
         
        </div>
      </div>
    </div>
  );
};

export default AdminProfile;