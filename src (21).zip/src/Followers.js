import React, { useState, useEffect } from 'react';
import { firestore } from './firebaseConfig';  
import { collection, getDocs } from 'firebase/firestore';  
import { useNavigate } from 'react-router-dom';  

const FollowersPage = () => {
    const [users, setUsers] = useState([]);  
    const [searchQuery, setSearchQuery] = useState('');  
    const navigate = useNavigate();
    const [filteredUsers, setFilteredUsers] = useState([]);  

   
    useEffect(() => {
        fetchUsers();
    }, []);

    const fetchUsers = async () => {
        try {
            const usersRef = collection(firestore, 'users');
            const snapshot = await getDocs(usersRef);
            const usersList = snapshot.docs.map(doc => doc.data()); 
            
            setUsers(usersList);  
        } catch (error) {
            console.error('Error fetching users:', error);
        }
    };

    
    useEffect(() => {
        const filtered = users.filter(user =>
            `${user.firstName} ${user.lastName}`.toLowerCase().includes(searchQuery.toLowerCase())
        );
        setFilteredUsers(filtered);
    }, [searchQuery, users]);

    const handleSearch = () => {
        console.log("Search Query:", searchQuery);
    };

    const handleUserClick = (userId) => {
        navigate(`/adminModeratorUserProfile/${userId}`);
    };

    return (
        <div className="followers-page">
            <h2>Followers</h2>
            
            
            <nav className="navbar">
                <h2>Welcome, Moderator</h2>
                <input
                    type="text"
                    className="search-input"
                    placeholder="Search..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                />
                <button className="search-btn" onClick={handleSearch}>Search</button>
                <button onClick={() => navigate('/UserProfile')}>Profile</button>
                <button onClick={() => navigate('/login')}>Logout</button>
            </nav>

           
            <div className="user-list">
                {filteredUsers.length === 0 ? (
                    <p>No users found.</p>
                ) : (
                    <table className="user-table">
                        <thead>
                            <tr>
                                <th>First Name</th>
                                <th>Last Name</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredUsers.map((user, index) => (
                                <tr key={index} onClick={() => handleUserClick(user.id)}>
                                    <td>{user.firstName || 'N/A'}</td>
                                    <td>{user.lastName || 'N/A'}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                )}
            </div>
        </div>
    );
};

export default FollowersPage;
